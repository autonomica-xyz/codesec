#!/usr/bin/env python3
"""Cell/block execution engine for the experiment runner (P07/P11).

Per block (repo × trial): prepare the paired bundle once, then execute the
two arms consecutively — each arm attempt in its own isolation container
with an outer wall deadline (full cap + at most 30 s cleanup grace,
enforced by docker's --timeout via subprocess timeout and reported
separately). Every attempt is ledgered; outputs are validated, adapted and
committed atomically with completion records. Model-call transient retries
stay INSIDE a cell (max three, deadline-aware); a pre-inference setup
failure may be retried once; task/recall/fallback failures are never
retried into fresh cells; the first inference-bearing attempt is the
operational primary.
"""

from __future__ import annotations

import hashlib
import json
import os
import secrets
import shutil
import subprocess
import sys
import time
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[2]
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

from bench.realvuln import adapter, isolation
from bench.realvuln.common import write_json
from bench.realvuln.ledger import AttemptLedger
from bench.realvuln.snapshot import latest_valid_snapshot, retain_snapshot

PYGOAT = "realvuln-pygoat"
CLEANUP_GRACE_S = 30.0

#: Wall ceilings per repo (seconds); early normal completion allowed.
def wall_ceiling_s(repo: str, settings: dict) -> float:
    overrides = (settings or {}).get("wall_ceiling_overrides_s") or {}
    if repo in overrides:
        return float(overrides[repo])
    return float((settings or {}).get("wall_ceiling_s", 7200))


def new_attempt_id() -> str:
    return f"att-{secrets.token_hex(6)}"


def prepare_or_reuse_bundles(exp: Path, manifest: dict, repo: str,
                             trial: int) -> Path:
    """One source bundle per (repo, trial), byte-identical H/V copies."""
    record_path = exp / "operator" / "prepared-bundles.json"
    record = (
        json.loads(record_path.read_text()) if record_path.exists() else {}
    )
    key = f"{repo}#trial{trial}"
    if key in record:
        bundles_dir = Path(record[key]["bundles_dir"])
        if (bundles_dir / "bundle.json").exists():
            return bundles_dir
    bundles_dir = (
        exp / "attempts" / f"bundles-{repo}-t{trial}"
    )
    realvuln = Path(
        os.environ.get(
            "REALVULN_ROOT",
            str(Path(manifest["settings"].get("realvuln_root", "/home/user/g/Real-Vuln-Benchmark"))),
        )
    )
    pair = isolation.prepare_bundle_pair(
        slug=repo, trial=trial, bundles_dir=bundles_dir, realvuln=realvuln,
    )
    record[key] = {
        "bundles_dir": str(bundles_dir),
        "digest": pair.digest,
        "dropped_paths": pair.dropped,
        "canary": pair.canary,
        "prepared_at": time.time(),
    }
    write_json(record_path, record)
    return bundles_dir


def run_arm_container(
    *,
    exp: Path,
    manifest: dict,
    cell: dict,
    attempt_id: str,
    target_dir: Path,
    gateway_url: str,
    timeout_s: float,
    repo: str,
) -> dict:
    """Execute one arm attempt in its isolation container.

    H: the codesec CLI with the frozen experiment config against the
    gateway. V: pinned pi, headless, isolated agent dir with the gateway
    provider definition. Both write only under /work/output/<attempt>."""
    output_dir = exp / "attempts" / attempt_id / "output"
    scratch_dir = exp / "attempts" / attempt_id / "scratch"
    settings = manifest["settings"]
    if cell["arm"] == "h":
        command = [
            "bash", "-lc",
            "codesec run --repo /work/target "
            f"--run-id {attempt_id} "
            "--run-root /work/output/run "
            "--config /usr/local/lib/python3.13/site-packages/config/stages.yaml "
            "--engine local "
            "--prior off "
            f"--max-concurrency {settings.get('h_concurrency', 4)} "
            f"--max-recon-tasks {settings.get('recon_tasks', {}).get(repo, 20)} "
            f"--max-hours {timeout_s / 3600.0:.4f} "
            "2>&1 | tee /work/output/codesec.log; exit ${PIPESTATUS[0]}",
        ]
    else:
        # V model definition: the frozen provider def with its baseUrl
        # derived from the experiment's gateway_url (never a stale alias).
        pi_dir = output_dir / "pi-home"
        pi_dir.mkdir(parents=True, exist_ok=True)
        definition = dict(
            manifest["settings"].get("pi_model_definition")
            or json.loads((exp / "operator" / "pi-model.json").read_text())
        )
        provider = next(iter(definition.get("providers", {}).values()), {})
        if provider:
            provider["baseUrl"] = gateway_url
        (pi_dir / "models.json").write_text(json.dumps(definition))
        prompt = (
            "You are auditing the web application source code in "
            "/work/target for security vulnerabilities. Read the source, "
            "then write your findings as JSON to /work/output/findings.json "
            "with schema {\"findings\": [{\"finding_id\": str, \"file\": str, "
            "\"line_start\": int, \"line_end\": int, \"cwe\": \"CWE-n\", "
            "\"severity\": str, \"description\": str, \"evidence\": str}]}. "
            "Include only real, source-backed findings."
        )
        import shlex
        command = [
            "bash", "-lc",
            "PI_CODING_AGENT_DIR=/work/output/pi-home pi "
            f"--model {settings.get('pi_model_id', 'zaihosted/glm-5.3')} "
            "--thinking low -p " + shlex.quote(prompt)
            + " 2>&1 | tee /work/output/pi.log; exit ${PIPESTATUS[0]}",
        ]
    env = {
        "ZAI_GATEWAY_KEY": "gateway-dummy",
        "PI_CODING_AGENT_DIR": "/work/output/pi-home",
    }
    return isolation.run_isolated(
        target_dir=target_dir,
        scratch_dir=scratch_dir,
        output_dir=output_dir,
        command=command,
        gateway_url=gateway_url,
        timeout_s=timeout_s + CLEANUP_GRACE_S,
        env=env,
    )


def export_arm_outputs(
    *,
    exp: Path,
    manifest: dict,
    cell: dict,
    attempt_id: str,
    output_dir: Path,
    target_dir: Path,
) -> dict:
    """Validate and adapt authoritative outputs to the frozen export
    formats. H: report.json (primary policy) + confirmed.json (secondary).
    V: retained findings snapshot (only pre-deadline captures)."""
    files: dict[str, Path] = {}
    drops: dict[str, dict] = {}
    if cell["arm"] == "h":
        run_root = output_dir / "run"
        report = run_root / "results" / "report" / "report.json"
        confirmed = run_root / "results" / "report" / "confirmed.json"
        if not report.is_file():
            raise FileNotFoundError(f"missing H report: {report}")
        primary_payload = json.loads(report.read_text())
        primary = adapter.adapt_findings(
            {"findings": [
                {
                    "file": f.get("file"),
                    "line_start": f.get("line_start"),
                    "line_end": f.get("line_end"),
                    "cwe": f.get("cwe"),
                    "severity": f.get("severity"),
                    "description": f.get("description"),
                    "finding_id": f.get("finding_id"),
                    "vuln_class": f.get("vuln_class"),
                }
                for f in primary_payload.get("findings", [])
            ]},
            target_dir,
        )
        secondary_payload = (
            json.loads(confirmed.read_text())
            if confirmed.is_file() else {"findings": []}
        )
        secondary = adapter.adapt_findings(
            {"findings": [
                {
                    "file": f.get("file"),
                    "line_start": f.get("line_start"),
                    "line_end": f.get("line_end"),
                    "cwe": f.get("cwe"),
                    "severity": f.get("severity"),
                    "description": f.get("description"),
                    "finding_id": f.get("finding_id"),
                }
                for f in secondary_payload.get("findings", [])
            ]},
            target_dir,
        )
        drops["primary"] = primary.drop_counts
        drops["secondary"] = secondary.drop_counts
        files["primary"] = output_dir / "primary.semgrep.json"
        files["primary"].write_text(
            json.dumps(adapter.semgrep_document(primary.results), indent=1)
        )
        files["secondary"] = output_dir / "secondary-confirmed.semgrep.json"
        files["secondary"].write_text(
            json.dumps(adapter.semgrep_document(secondary.results), indent=1)
        )
    else:
        findings_path = output_dir / "findings.json"
        retained = retain_snapshot(findings_path)
        if retained is None and not findings_path.exists():
            raise FileNotFoundError(
                f"missing V findings output: {findings_path}"
            )
        source = Path(retained) if retained else findings_path
        payload = adapter.parse_findings_document(source.read_text())
        adapted = adapter.adapt_findings(payload, target_dir)
        drops["primary"] = adapted.drop_counts
        files["primary"] = output_dir / "primary.semgrep.json"
        files["primary"].write_text(
            json.dumps(adapter.semgrep_document(adapted.results), indent=1)
        )
    return {"files": files, "drops": drops}


def execute_block(
    *,
    exp: Path,
    manifest: dict,
    ledger: AttemptLedger,
    cell: dict,
    block: dict,
) -> dict:
    """Run one cell (one arm of one block) with ledger + atomic commit."""
    from bench.realvuln.experiment import (
        arm_done,
        cell_id_of,
        commit_cell_outputs,
    )

    repo = cell["repo"]
    settings = manifest["settings"]
    gateway_url = settings.get("gateway_url", "http://gateway:8800/v1")

    committed_cell = exp / "committed" / cell["cell_id"]
    done = arm_done(
        committed_cell, manifest=manifest, arm=cell["arm"],
        repo=repo, trial=cell["trial"],
    )
    if done["done"]:
        return {"ok": True, "already_committed": True}

    bundles_dir = prepare_or_reuse_bundles(exp, manifest, repo, cell["trial"])
    pair_manifest = json.loads((bundles_dir / "bundle.json").read_text())
    target_dir = bundles_dir / cell["arm"] / "target"

    attempt_id = new_attempt_id()
    ledger.append({
        "type": "attempt_start",
        "cell_id": cell["cell_id"],
        "attempt_id": attempt_id,
        "arm": cell["arm"],
        "trial": cell["trial"],
        "bundle_digest": pair_manifest["digest"],
    })

    output_dir = exp / "attempts" / attempt_id / "output"
    ceiling = wall_ceiling_s(repo, settings)
    made_inference = False
    try:
        result = run_arm_container(
            exp=exp, manifest=manifest, cell=cell, attempt_id=attempt_id,
            target_dir=target_dir, gateway_url=gateway_url,
            timeout_s=ceiling, repo=repo,
        )
        made_inference = (output_dir / "run").exists() or any(
            output_dir.glob("findings.json*")
        )
        exported = export_arm_outputs(
            exp=exp, manifest=manifest, cell=cell, attempt_id=attempt_id,
            output_dir=output_dir, target_dir=target_dir,
        )
        marker = commit_cell_outputs(
            exp=exp, manifest=manifest, cell=cell, attempt_id=attempt_id,
            export_dir=output_dir, files=exported["files"],
        )
        status = "completed" if result["exit_code"] == 0 else "failed_output"
        ledger.append({
            "type": "attempt_end",
            "cell_id": cell["cell_id"],
            "attempt_id": attempt_id,
            "status": status,
            "reason_code": (
                "ok" if result["exit_code"] == 0
                else f"arm_exit_{result['exit_code']}"
            ),
            "exit_status": result["exit_code"],
            "made_inference_requests": made_inference,
            "duration_s": result.get("duration_s"),
            "bundle_digest": pair_manifest["digest"],
            "attempt_selection": "first_execution_primary",
            "artifact_sha256": {
                role: marker_name for role, marker_name in []
            },
            "drops": exported["drops"],
            "completion_marker": str(marker),
        })
        return {"ok": True, "status": status, "attempt_id": attempt_id}
    except FileNotFoundError as error:
        # Terminal output failure — ledgered, never silently retried into a
        # fresh cell. Failed cells aggregate per P08 rules.
        ledger.append({
            "type": "attempt_end",
            "cell_id": cell["cell_id"],
            "attempt_id": attempt_id,
            "status": "failed_no_output",
            "reason_code": "missing_output",
            "exit_status": None,
            "made_inference_requests": made_inference,
            "error": str(error)[:400],
            "attempt_selection": "operational_failure_recorded",
        })
        return {"ok": False, "reason": f"missing_output: {error}"}
    except isolation.IsolationError as error:
        ledger.append({
            "type": "attempt_end",
            "cell_id": cell["cell_id"],
            "attempt_id": attempt_id,
            "status": "setup_failed",
            "reason_code": "isolation",
            "exit_status": None,
            "made_inference_requests": False,
            "error": str(error)[:400],
            "attempt_selection": "setup_retry_eligible_once",
        })
        return {"ok": False, "reason": f"isolation: {error}"}
