# Repair & retest progress log

Plan: `bench/PLAN-REALVULN-REPAIR-AND-RETEST.md` (created 2026-09-22).
Executed from `/home/user/g/codesec`. Evidence under `bench/realvuln/repair-evidence/<pkg>/`.

## P00 — Preserve evidence and establish a baseline — COMPLETE (2026-09-22)

Commands and exit codes (all from `/home/user/g/codesec`):

| Step | Command | Exit | Evidence |
|---|---|---|---|
| status/HEAD/diff | `git status --short; git rev-parse HEAD; git diff; git diff --stat` | 0 | `p00/git-status.txt`, `p00/HEAD` (`5cd7d2429232a0e627613bbf5bf617e6623aef37`), `p00/tracked-diff.patch`, `p00/tracked-diff-stat.txt` |
| source snapshot | `.venv/bin/python /tmp/p00_snapshot.py` (script inline in session log below) | 0 | `p00/source-snapshot.json` — 181 files (tracked-at-worktree + untracked source incl. bench/realvuln, plans, results), sha256 per file; tree digest `b67054de…d326b6a3d1c20`. Excludes venv/caches/runs/results/credentials. A HEAD hash alone would not identify this dirty workspace; the snapshot plus tracked-diff.patch does. |
| historical inventory | `.venv/bin/python /tmp/p00_inventory.py` | 0 | `p00/runs-inventory.json` — 107 run dirs, 63 with `state.db` (read-only URIs, per-table counts, sha256). No live `-wal`/`-shm` found. One orphan Django devserver (`0d748f45/work/hunt/t_labs_log_injection/repo/... manage.py runserver 127.0.0.1:8765`, pid 635301) was still running **inside the runs tree**; it was stopped (`kill 635301`; verified gone) before declaring the archive immutable. It belonged to the historical experiment (path under `bench/realvuln-runs/`), not an unrelated host service. No other active writers found. Original logs/timestamps untouched. |
| audit rerun | `.venv/bin/python -m bench.realvuln.audit_saved_run > p00/realvuln-before.json` | 0 | F3 means reproduce exactly: hunt 40.4 / final 20.8 / pi 21.4; `dedupe_fallback=18`, `report_fallback=18`; confirmed=340, rejected=43, needs_more_info=5; traces 156 reachable/178 uncertain/6 unreachable, **0 missing** (no `trace:missing` key). hunt_tp_absent_from_final=98. Historical artifacts unchanged. |
| offline test suite | `.venv/bin/python -m pytest -q` | 0 | `p00/pytest-baseline.txt`: **337 passed, 14 skipped in 35.56s**. Skips are explicitly gated: 13 × `tests/test_auth.py` (`claude CLI not installed`), 1 × `tests/test_seeded_fp.py:149` (`live bench only` marker, skip condition already explicit). Reviewed suite for implicit external-service use: auth tests manipulate env vars with fake keys only; no live network call in the offline suite. |
| staging dirs | `mkdir -p bench/realvuln/repair-evidence/p00 bench/realvuln-runs/experiments` | 0 | Experiments parent created; final experiment path deliberately **absent** until P11 `freeze`. |

Credential handling: sweep of `config/`, bench scripts, plans found no credential-like
strings; snapshot excluded credentials by construction. Scanner tags `glm53` /
`unsloth-qwen38-q4` not reused anywhere in P00.

Deviations: none. Unresolved: none.

Snapshot script used (transient, `/tmp/p00_snapshot.py`): walked tracked files
(`git ls-files`) at worktree state plus untracked files under
`codesec/ tests/ prompts/ schemas/ config/ bench/realvuln bench/probe bench/corpus`
and the listed top-level/bench files, hashing every byte; excluded
`__pycache__ .venv node_modules .git *.egg-info bench/realvuln-runs results repair-evidence`.
Inventory script (`/tmp/p00_inventory.py`): read-only per-run record of
`run-manifest.json`, `benchmark_meta.txt`, logs, per-table DB counts and DB sha256.

## P01 — Repair Read/Grep/Glob behavior in blinded trees — COMPLETE (2026-09-22)

Changes (`codesec/local_agent.py`):
- Ignore rules now apply to path parts **relative to `repo_root`** (was: absolute
  path parts, which blinded every `/tmp/<opaque>/target` repo). A repo root
  named `target` is fully searchable; a nested `target/` build dir stays ignored.
- Centralized containment/exclusion in `_resolve_in_repo` / `repository_scope` /
  `iter_repo_files` shared by Grep and Glob. Symlinks resolved before accepting
  files; escapes outside the repo rejected for explicit paths and skipped
  (with an explicit `[skipped N symlink(s) escaping the repository]` notice)
  during enumeration. Deterministic ordering: enumeration sorted by path.
- Grep `path` = regular file → search exactly that file (was: rglob on a file →
  always empty). Directory → recurse. Missing path → explicit
  `[tool error: FileNotFoundError: ...]`, never `(no matches)`.
- Glob `path` must be a directory (explicit `NotADirectoryError` otherwise);
  results sorted, unique, repo-relative, capped as before; matching via
  `PurePath.full_match` preserving old `**/…` vs `*.py` semantics without the
  symlink-following of `glob.glob`.
- Read: offset beyond EOF now returns `(no lines at offset N; total_lines=M)`
  instead of a misleading `(empty file)`.

Internal-symlink policy (documented in `iter_repo_files` docstring and tests):
symlinked files resolving inside the repo are searchable; symlinked directories
are not traversed during recursion (pathlib rglob default), so recursion can
never escape and duplicate/escape behavior is deterministic.

Tests (`tests/test_local_agent.py`, +10 behavior tests, all through `_exec_tool`):
repo root named `target`; `target` ancestor of a differently named root; nested
`target/` still ignored; `.git/.venv/node_modules/__pycache__/dist` excluded
consistently across Grep/Glob incl. scoped patterns; file- vs directory-scoped
Grep agreement; missing path vs no-matches vs tool-error distinguishable;
external symlink + `../` traversal cannot expose host files; internal symlink
determinism; content/count/files modes under a `target` root; 1500-line Read
paging with no skipped/repeated lines; offset-beyond-EOF and empty-file notices.

- `pytest -q tests/test_local_agent.py` → **32 passed**.
- Full suite → **347 passed, 14 skipped** (no regressions).
- Exit-gate reproduction saved: `bench/realvuln/repair-evidence/p01/three-tool-repro.txt`
  (Read/Grep/file-scoped-Grep/Glob all succeed under `/tmp/b8389c35/target`).

Deviations: none beyond documented internal-symlink policy above.

## P02 — Bound synthesis inputs and deterministic report membership — COMPLETE (2026-09-22)

Config (`codesec/config.py`): new effective settings `report_policy`
(`confirmed_all` default | `confirmed_reachable` | `confirmed_except_unreachable`)
and `report_renderer` (`agent` default | `deterministic`), loadable from
`config/stages.yaml` top-level keys, validated in `__post_init__`. Defaults
preserve historical product behavior outside the experiment; the experiment
selects `confirmed_reachable` + `deterministic` (recorded in manifest later).

State (`codesec/state.py`):
- Membership defined once: `get_report_findings(run_id, policy)` +
  `trace_status()` normalizer + `report_membership_snapshot()` emitting every
  evidence tier (reachable/uncertain/unreachable/untraced id lists) so nothing
  disappears from the review record.
- New backward-compatible `stage_events` table (CREATE IF NOT EXISTS on init;
  no destructive migration) with `record_stage_event`/`get_stage_events` —
  shared by P02 degraded events and P05 stage health.

Report (`codesec/stages/report.py`):
- `run_deterministic_report` is now the *intended* renderer when configured
  (orchestrator selects by `config.report_renderer`), not a caught exception.
  Zero model calls (opt-in grade knob unchanged, default off). Records
  `intended` stage event; schema failure raises StageContractError and records
  `failed` — never an empty success.
- Every render path writes `report.json` (primary policy), `confirmed.json`
  (all confirmed canonicals, deterministic, schema-validated) and
  `review_queue.json` (uncertain/untraced/unreachable/needs-more-info with
  explicit reasons incl. `excluded_by_policy:<policy>` labels, failed tasks,
  degraded/failure stage events).
- `_reconcile_report_membership` now forces DB-authoritative file, line range,
  vuln_class, CWE and trace from the DB — an LLM payload cannot relocate,
  reclassify, or drop members (test with a lying agent proves it).

Dedupe (`codesec/stages/dedupe.py`) — rewritten `run_dedupe`:
- Bounded descriptor per finding (id/file/range/class verbatim; description,
  evidence ≤400 chars, validation rationale ≤240, explicit `truncated` flags).
- Partition by (normalized file, vuln_class); ordered batches packed against
  the **actual serialized wrapper** under a 30,000-char cap (below the 50k
  engine guard); per-descriptor oversize raises typed `DedupeOversizeError`.
- One adjudication call per batch (preclusters restricted to in-batch groups);
  bounded representative merge pass only for partitions spanning ≥2 batches —
  all representatives when they fit, else only precluster-linked cross-batch
  candidates, else conservative keep-separate (`merge_skipped_oversize`).
  Cross-partition groups are never merged; restriction recorded as an event.
- Final exact-partition contract over every confirmed id (typed
  `DedupeContractError` on violation). Failed batches/merges keep
  deterministic singleton/pre-merge groups **with degraded stage events**
  (`batch_failed`, `batch_contract_violation`, `merge_failed`), never silent
  success. Batch/merge request+response artifacts saved with stable ids.
- Size telemetry event (`input_size`: findings/batches/max chars) per run.

Other stages: `record_input_size` telemetry wired into recon, hunt (per task),
validate (per review/arbiter call), gapfill, trace (per finding), feedback,
report-agent; `truncated_recon_summary` now bounds verbose free text per entry
(paths/names preserved). Inspection of other builders: feedback/trace embed
full finding JSON — bounded by the engine's explicit 50k guard (fails loudly,
visible in telemetry); no silent truncation anywhere. Recorded as residual
risk for very large confirmed sets in feedback input.

Tests: +12 dedupe behavior tests (payload bounds at 1/60/200 findings with
40k-char evidence; straddling-batch merge with mocked adjudicator keeping
unrelated bugs distinct; unknown/missing/duplicate membership → deterministic
singletons + degraded events; model failure; malformed merge; empty input;
oversize descriptor typed error; cross-partition never merged; oversize merge
skip), +6 report tests (policy membership across all trace states; secondary
confirmed.json; review-queue reasons; zero-model-call deterministic renderer
with stable finding-id ordering; renderer failure = error; lying-agent
reconciliation), +3 config tests. Full suite: **364 passed, 14 skipped**.

History-derived offline check (copies only, historical DBs untouched):
`bench/realvuln/repair-evidence/p02/historical-db-descriptor-check.txt` —
smallest saved DB (1 confirmed) → 1 batch; largest (55 confirmed, run 3e5fd985)
→ 3 batches, max batch 29,925 ≤ 30,000 chars, every id assigned exactly once.

Deviations: merge pass bounds representatives more tightly (120-char
summaries) than batch descriptors (400) so a realistic two-batch partition
fits one merge request; when even that fails the conservative keep-separate
path is taken with an explicit event (plan allows conservative separation;
never an unbounded concatenation).

## P03 — Explicit provider settings + wire-request verification — COMPLETE (offline gates; live probe deferred to P10) (2026-09-22)

New `codesec/reasoning.py`: provider-aware `ReasoningSpec` (protocols
`none | llama_chat_template | zai_thinking`; zai requires enabled + effort
low/high/max and rejects disabled). `effective_request_settings()` produces
the canonical settings dict + sha256 fingerprint (hash the effective config,
not a YAML path). Request shapes: zai → `thinking:{type:enabled}` +
`reasoning_effort`; llama → `chat_template_kwargs.enable_thinking` (local
only, never the hosted control); none → no reasoning key at all.

`codesec/config.py`: ModelProfile gains reasoning_protocol/enabled/effort/
history; `reasoning_spec()` maps legacy `thinking: true` to the llama
protocol for backward compat. `codesec/runner.py`: passes the serialized
spec; **new hard conflict check** — a stage label naming one model while an
attached profile would send another raises ValueError (audit's silent
wrong-profile override; legacy test asserting the silent override updated to
the new contract).

`codesec/local_agent.py`:
- `_consume_sse` preserves streamed reasoning (`reasoning_content`/
  `reasoning`/`reasoning_text` — the same field set Pi reads) on the
  assistant message and keeps usage verbatim (reasoning/cache details kept
  when supplied, never fabricated).
- Assistant history messages serialize `reasoning_content` back on later
  requests per policy `preserve` (including tool-call turns) — Pi-compatible
  transport.
- Usage accounting tracks `reasoning_tokens` with a `reasoning_reported`
  flag (absent ⇒ unknown, not zero).
- Artifact meta records the full effective request settings + fingerprint.
- Optional `CODESEC_REQUEST_HEADERS` env adds operator tag headers
  (experiment/cell/attempt/stage) for gateway attribution.

Provider facts (archived 2026-09-22 to `bench/realvuln/repair-evidence/p03/`):
- `zai-docs-glm53-2026-09-22.html`: glm-5.3 `thinking.type` enabled-only
  (requests with `disabled` FAIL); `reasoning_effort` low/high/max, default
  max; example `{"thinking":{"type":"enabled"},"reasoning_effort":"max"}`.
- `zai-docs-glm52-reasoning-content-2026-09-22.html`: streaming responses
  deliver `delta.reasoning_content`.
- Pi 0.85.1 request builder (bundle inspected, not modified): zai
  thinkingFormat sends `thinking:{type:enabled,clear_thinking:false}`;
  detected zai compat sets `supportsReasoningEffort=false` BUT per-model
  `compat` overrides exist (incl. `thinkingFormat`, `supportsReasoningEffort`,
  `maxTokensField`); `samplingParams` from the model definition merge into
  request params; assistant history carries `reasoning_content` with that
  signature. **No Pi patch needed** — an isolated provider/model definition
  reproduces the frozen protocol.

New files:
- `bench/realvuln/gateway.py` — operator-side inference gateway/recorder:
  one allowlisted upstream+model, frozen-setting validation BEFORE forwarding
  (mismatch ⇒ 400, never rewritten), operator-held credential (agent gets a
  dummy key; Authorization never logged), per-request JSONL records (IDs via
  X-* header tags, stage, observed settings + extras, message counts/roles/
  reasoning-count/sha256 — no message content, stop reason, verbatim usage,
  HTTP errors, duration; rejected requests recorded separately).
- `bench/realvuln/pi-hosted-model.json` — isolated Pi provider/model
  definition (zaihosted/glm-5.3 via gateway; compat overrides; temperature
  0.6 no top_p; maxTokens 32768; contextWindow 262144).
- `config/zai-glm53-experiment.yaml` — frozen codesec-side experiment
  config; effective fingerprint `cf9d42d2da75e9ebdefebe30e58b9a33eb2711e2f9d916ec8dfada8e35d59adf`.

Tests (+16): SSE chunked reasoning+content+tool calls w/ usage fidelity;
missing usage stays missing; malformed events skipped; truncation
(IncompleteRead) → transient; terminal HTTP 400 → RuntimeError; zai/llama
wire shapes; history drop/preserve policies; spec rejects disabled/bad
effort; canonical fingerprint; **real codesec client driven against a local
mock server** (effective controls + tool-turn reasoning transport + usage);
**gateway suite** (passthrough+records, sanitized/credential-free records,
6 mismatch rejections, missing-setting rejection, route allowlist, upstream
error recording, reasoning-history visibility); **real installed Pi client
(`pi -p`, isolated PI_CODING_AGENT_DIR + HOME) driven against a mock server**
— glm-5.3, thinking enabled, reasoning_effort low, temperature 0.6, no
top_p, max_tokens 32768, stream, no chat_template_kwargs, real tool
round-trip with reasoning_content history transport (verified manually:
2 requests, assistant history carries reasoning, tool result present; Pi
extras `clear_thinking`/`store` recorded-but-not-enforced by the gateway).

Full suite: **388 passed, 14 skipped**.

Deferred to P10 (live, per plan): one tiny real tool round-trip per client
through the production gateway against the real endpoint, and server-side
context-262144 verification. Deviations: none (documented decision: codesec
sends the documented `{"type":"enabled"}` shape; Pi's extra undocumented
`clear_thinking:false` is preserved by Pi and recorded by the gateway under
observed_extra rather than falsified into equality).

## P04 — Static/live evidence separation + Trace contract repair — COMPLETE (2026-09-22)

Evidence mode (`codesec/stages/_common.py`): `StageContext.evidence_mode`
(static|live). `extras()` now always emits `evidence_mode`; static inputs
carry `live_target: null` AND `markers: null` explicitly (a template example
can never be mistaken for a real deployment); live inputs carry the real
target. `ctx.prompt(name)` selects `<name>.live.md` in live mode when
present, else the base file — the base files are the STATIC variants.

Prompts: `01-recon/02-hunt/03-validate/03-arbiter/06-trace` base files
rewritten static-only — every concrete example host (`server.local`),
credential example, and marker-token example removed from static inputs;
explicit "static, source-only" sections stating there is no URL, no runtime
credentials, no HTTP round trips, no deployment inference; source evidence +
isolated local in-process PoCs are the evidence standard; absence of a live
repro is never a rejection signal. `.live.md` variants preserve the live
machinery (markers, auth-on-the-wire, egress-to-target-only) with example
hosts replaced by `<the deployed target URL from input>` placeholders so even
live prompts contain no dial-able example host.

Trace contract (`codesec/contracts.py` + `schemas/trace.schema.json`):
- Input names the authoritative sink; the reachable trace's FINAL frame must
  sit at exactly that file/range; reversed chains fail with an explicit
  entry-to-sink message.
- One-frame chains valid when the handler is both entry and sink
  (schema minItems 1 + contract >= 1); no manufactured second callsite.
- Executable frames must be repo files at valid lines (checked against real
  file lengths, error includes the file's line count). Dependency/framework
  crossings go to a new `boundary_frames` array ({boundary, location,
  assumption}) validated for shape but never treated as repo files; a
  genuinely unresolvable boundary is an uncertainty, not a fake frame.
- New typed `uncertainty` {kind: source_evidence|operational, reason_code}
  required for uncertain traces — source-level uncertainty is never conflated
  with operational failure; `trace_failure_reason_code()` maps failed
  invariants to machine-readable codes (sink_mismatch, missing_repo_frame,
  invalid_line, …).

Trace stage (`codesec/stages/trace.py`, rewritten): `authoritative_sink` in
every input; bounded semantic-repair loop (max two repairs, every attempt
preserved as artifacts + stage events) whose repair input carries finding id,
the exact failed invariant, the authoritative sink, and the invalid payload;
each attempt re-validated. Exhausted repair → uncertain with
kind=operational and the mapped reason code; frames are never moved or
auto-reversed; engine failures (including during repair) → uncertain
engine_failure, never unreachable. Static mode never mints markers and never
requires one; live mode keeps the verified-marker reachable gate (tested).

Tests (+16 contract/stage behavior tests): valid multi-frame chain; direct
one-frame route; reversed chain; wrong sink range; out-of-repo dependency
frame (rejected in call_chain, message points at boundary_frames); missing
file; invalid line (with file length reported); uncertain-without-type
rejected; auth-gated reachable; dead-branch unreachable; static trace needs
no marker (the audit's 45 server.local downgrades fixed); live trace without
verified marker still rejected after repairs; semantic repair success
(structured repair message asserted); repair exhaustion (exactly 1+2 calls,
missing_repo_frame typed); repair interrupted by engine failure
(engine_failure during semantic_repair event); static/live prompt selection +
no example hosts in any static prompt. Suite: **404 passed, 14 skipped**.

Deviations: none. (`P06` enforces the actual egress denial at the sandbox
level, as the plan assigns it there.)

## P05 — Deadline enforcement + stage health — COMPLETE (2026-09-22)

New `codesec/deadline.py`: one `Deadline` object per run (monotonic clock)
with `synthesis_reserve_fraction = 0.20` — `closing()` is elapsed >= 80% of
the total budget (fixes the audit's 20%-elapsed "closing"); `exhausted()` is
remaining <= 30 s `FINAL_SNAPSHOT_RESERVE_S`; `check()`/`check_closing()`
gate stage admission; `request_timeout()` bounds sockets by remaining time
(+snapshot allowance, never beyond the total); `clamp_sleep()`/`sleep()`
mean backoff never crosses the deadline and a request is never restarted
after exhaustion (TimeBudgetExceeded instead).

Plumbing: `Deadline` created in `run_pipeline` and carried on
`StageContext.deadline`; every stage's `run_agent` call passes
`deadline=ctx.deadline`; `runner.run_agent` checks the deadline before
starting, passes `deadline_ts` to the local engine, and its retry loop uses
`deadline.sleep`. `local_agent._chat` bounds the socket timeout by the
remaining budget; the Bash tool is rewritten with `Popen(start_new_session=
True)` + process-group SIGKILL on expiry (bounded by remaining budget), so
hanging children AND grandchildren are terminated as a unit — no orphans
(the outer container deadline at cap+30 s grace is enforced by the P06/P11
runner boundary, reported separately).

Orchestrator: closing semantics reworked — breadth (Hunt/Gapfill/Feedback)
is admitted only before closing, with explicit `budget_limited` stage-health
records when skipped; synthesis (dedupe/trace) runs in the remaining budget;
a deterministic mid-run report CHECKPOINT (`report.checkpoint.json`, zero
model calls, atomic) is written after trace so a budget kill before the
final report still leaves a well-defined latest primary snapshot; on
TimeBudgetExceeded the pipeline finishes `budget_limited` (DB status) and
exports the checkpoint, or documents the no-output failure. All report JSON
writes (report/confirmed/review_queue/checkpoint) are atomic
(tmp+fsync+rename) — a crash can never leave a truncated document shadowing
a previous valid one. `_StageHealth` context manager records per stage call:
intended implementation, model/profile/concurrency, start/end, elapsed, and
status complete/budget_limited/degraded/failed + error category
(backward-compatible `stage_events` table; no destructive migration).

New `bench/realvuln/snapshot.py` (V-arm side): `retain_snapshot` captures a
findings file only when it is fully written and valid (optional schema
gate); truncated overwrites never destroy the previous snapshot;
`latest_valid_snapshot` returns only pre-deadline captures.

Tests (+19): fake-clock closing (2 h: not closing @24 min, closing @96 min;
3 h: closing @144 min); snapshot reserve = exhausted; request timeout
bounded by remaining; backoff never sleeps past the deadline nor restarts
(one attempt only); run_agent refuses to start after exhaustion; hung model
server abandoned within budget bound (real socket); hanging Bash tool +
grandchild killed with process group, zero orphans (pgrep-verified); failed
dedupe batch + failed task visible in stage ledger beside a valid
deterministic report ("intended", not fallback); atomic write never shadows a
valid snapshot and leaves no temp files; stage-health budget_limited
recording; 5 snapshot-retention behavior tests. Suite: **423 passed, 14
skipped** (grew after snapshot tests).

Deviations: none. Outer container kill at cap+30 s is implemented at the
P06/P11 isolation/runner boundary as the plan assigns it there.

## P06 — Operator/agent isolation + paired corpus integrity — COMPLETE (2026-09-22)

New `bench/realvuln/isolation.py`:

- **Pin + integrity**: `verify_pin` (HEAD == `7a710251…`, tracked tree clean,
  untracked outputs reported); `verify_gt_locations` (every GT finding's
  file present with bytes unchanged from the source checkout, ranges within
  file bounds); `digest_tree_v2` (hashes relative paths + file content +
  **symlink targets** — a link swap changes the digest); `verify_symlink_policy`
  (only links resolving inside the tree; dangling AND escaping links block).
- **Paired bundles**: `prepare_bundle_pair(slug, trial)` — one source bundle
  per (repo, trial), identity stripping applied ONCE on the H copy then
  mirrored byte-identically to V (digest equality enforced, manifest records
  dropped paths + digest + `scored: true`). **Scored bundles contain no
  canary.** Unscored canary fixtures (opt-in) record the exact inserted
  interval and enforce >20-line separation from the furthest GT line in the
  host file (covers ±10 acceptance windows incl. acceptable locations, which
  share the file/line records); both arms stay byte-identical including the
  fixture.
- **Container isolation** (docker, verified available on this host — note:
  pre-existing `hunt_app`/`hunt_redis` containers from earlier live-target
  work were left untouched): pinned image built from a source ALLOWLIST
  (codesec package, prompts, schemas, experiment config only — never
  `COPY .` of the workspace; no bench/, no .git; pinned `pi@0.85.1` for the
  V arm; image id recorded). One container per arm attempt: uid 10001,
  `--read-only` rootfs, `/work/target:ro` MOUNT (not chmod), writable
  scratch/output (operator chown to 10001), `--cap-drop ALL`,
  `no-new-privileges`, `--pids-limit`, `--init`, private `--internal` docker
  network carrying only the gateway (alias `gateway`), env scrubbed to an
  allowlist (no host proxy/cloud creds, no provider key — `ZAI_GATEWAY_KEY`
  is the dummy; the credential lives operator-side in the gateway).
- **Access suites through the same bash boundary agents use**: negatives —
  host home, operator map, GT labels, prior runs, codesec checkout, docker
  socket, sudo, host PID visibility, host root via /proc/1, general egress,
  target writes, rootfs writes (all must fail); positives — target reads,
  scratch writes, output publication, gateway reachability (when configured).
  Docker-level infra failures (exit 125 / daemon errors) are NEVER counted
  as passes. `require_isolation()` blocks scored execution on any failure;
  `require_docker()` blocks rather than falling back to cwd isolation.

Also: `measure_identity_mentions` in common.py (equivalent model-authored
fields only; recognition reported, never an outcome-based exclusion) and the
unscored **reachable-mutation fixture**
(`bench/realvuln/fixtures/reachable-mutation/` — reachable unauthenticated
`eval` at app.py:14 as the positive control for source reading + static
reachability; canary misses never label cheating).

Tests (+12): pin match/dirty/wrong-SHA; digest symlink-target sensitivity;
symlink escape + dangling rejection; scored bundle pair byte-identical +
canary-free + GT bytes unchanged + identity drops consistent; GT tamper
detection; canary fixture interval + separation recording; existing-dir
refusal; docker-absence blocks; env allowlist excludes credentials;
identity-mention metric; **real docker suite** (15 checks all passing —
negative access through the container bash boundary, positive tool-path
checks) and **real image content checks** (harness importable, pi installed,
no source staging, no workspace, no sudo). Live evidence:
`bench/realvuln/repair-evidence/p06/isolation-test-offline.json` (14/14 + the
in-test gateway-optional variant), image id in
`bench/realvuln-runs/image-build.json` (`0c3d7165e2c5…`, pi 0.85.1).

Full suite: **435 passed, 14 skipped**. Gateway-reachable positive check
executes in P10 against the production gateway. Deviations: scratch/output
mount ownership uses passwordless sudo chown (available here); without sudo
a recorded weaker 0777 fallback exists — container separation unaffected.

## P07 — Immutable experiments, attempt ledger, atomic exports — COMPLETE (2026-09-22)

New modules:

- **`bench/realvuln/ledger.py`** — append-only, `fcntl`-locked, experiment-
  scoped attempt ledger replacing shared `failed-trials.txt`. Events carry
  experiment id, opaque cell/attempt ids, timestamps, config hash, status,
  reason code, exit status, artifact hashes, attempt-selection reason.
  Terminal records can never be rewritten; one experiment = one config
  hash (mismatched appends rejected); first inference-bearing attempt is
  the operational primary (a later successful diagnostic rerun cannot
  replace it); pre-inference setup failures leave the primary to the real
  attempt.
- **`bench/realvuln/experiment.py`** — the P11 command contract:
  `freeze --spec SPEC --output EXP` (refuses existing output; manifest
  hashes the canonical effective configuration + source tree + prompts/
  schemas/bench code + dirty diff + benchmark pin + settings + expected
  cells + schedule seed/order + retry/failure-scoring rules + metric —
  `no_secrets: true`; separate `manifest.sha256`; self-hash verified on
  load), `run --experiment EXP` (schedule-driven, idempotent resume,
  per-cell arm execution, failures retained), `verify --experiment EXP`
  (marker + artifact hashes + JSON validity + cell accounting + protocol
  consistency; never whether H wins), `preflight` (P09 wires the gates).
  Layout exactly per plan (`operator/`, `attempts/<opaque-id>/`,
  `committed/<opaque-cell-id>/completion.json` + primary/secondary
  exports, `reports/`); one run-root resolver honors
  `CODESEC_REALVULN_RUNS` everywhere; agent-visible paths use opaque ids
  only. Schedule: sorted slugs, per-repo 3 paired blocks, H-first counts
  2/1 via seeded selection, orders assigned to trials then 18 blocks
  shuffled with the recorded seed — 9 H-first / 9 V-first, verified by
  test. `arm_done` verifies marker + identity + artifact hashes + JSON
  validity (truncated/leftover artifacts are NOT completion and never
  block an eligible retry). `commit_cell_outputs` validates → hashes →
  atomic directory rename → completion record LAST (the commit marker).
- **`bench/realvuln/executor.py`** — per-block execution: paired bundles
  prepared once per (repo, trial) and recorded in `prepared-bundles.json`;
  arms run consecutively through `isolation.run_isolated` with the outer
  wall ceiling (7,200 s; PyGoat override 10,800 s) + 30 s cleanup grace;
  H exports primary (policy report) + secondary (confirmed) through the
  strict adapter; V uses retained pre-deadline findings snapshots only;
  ledger events distinguish completed / failed_output / failed_no_output /
  setup_failed, with `made_inference_requests` driving primary selection.
- **`bench/realvuln/adapter.py`** — strict validation: findings must be a
  list of objects (typed `AdapterInputError` for missing/malformed —
  distinct from a valid `findings: []`); traversal/absolute/`..`-component
  paths rejected; nonexistent files, boolean lines, non-integer lines,
  out-of-file and inverted ranges dropped; CWE shape strict `CWE-<n>`,
  never inferred; every drop counted with a stable reason; the frozen
  symmetric JSON escape repair. The image was also fixed so the installed
  harness finds prompts/schemas/config at the python prefix.

Tests (+28): ledger append-only/no-truncate, terminal rewrite rejection,
config-hash scoping, operational-primary selection (failed_output beats
later success), setup-failure-not-primary, unaccounted cells, concurrent
controller interleaving (all lines parse); manifest freeze/refuse-existing,
hash roundtrip + tamper detection, schedule counterbalance + determinism,
expected-cell coverage; commit/arm_done (hash verify, truncated artifact,
wrong experiment hash, missing marker, double-commit rejection, crash
during marker write leaves cell retry-eligible); executor failure
injection with fake arms (failure before output → failed_no_output,
nothing committed; nonzero exit WITH valid report → committed +
ledgered failed_output + idempotent resume (no re-run); valid empty
output → completed); adapter behavior suite. Full suite: **465 passed,
14 skipped**.

Deviations: executor's live arm wiring (real gateway/model) exercises in
P10/P11; the V-arm prompt is frozen in the executor (one headless audit
task, no continuation/score-aware steering, per the frozen decisions).

## P08 — Complete, paired, failure-honest aggregation — COMPLETE (2026-09-22)

`bench/realvuln/aggregate.py` gains the manifest-driven experiment mode
(`--experiment EXP`, the P11 aggregation command; the legacy tag mode and
`_pool` remain for historical reproducibility):

- Driven exclusively by `manifest.expected_cells` (self-hash verified) —
  no glob discovery. Duplicate cell assignments, unledgered expected
  cells, and config-hash mismatches are protocol errors.
- Cell resolution: committed artifact (arm_done-verified) → real
  predictions; `failed_no_output`/`failed_output`-without-artifact after
  inference → **empty predictions** (all scored positives FN, decoys TN),
  flagged `output_failure`, `agent_authored: false`; `setup_failed` with
  zero inference → experiment incomplete, headline blocked;
  `invalidated` → protocol breach blocks the headline (never repaired by
  zeros); no terminal state → progress report with `headline: null`,
  CLI exit 1 — never means over available subsets.
- Pooling: per trial per arm across the EXACT frozen repo list (partial
  trials are errors, not silently smaller denominators); official F3
  formula/rounding via the existing `_pool` (reproduces official numbers,
  per the audit); mean of the three trial F3s; raw counts kept.
- Decision implemented EXACTLY: (F3_H ≥ F3_V+5 OR (R_H ≥ R_V−.05 AND
  P_H ≥ P_V+.10)) AND strictly-fewer H FPs on ≥4/6 repos in ≥2/3 trials
  (ties never count); precedence invalid/incomplete → positive → does
  not meet success criterion; the original negative-condition framing is
  reported separately from the mechanically computed booleans.
- FP taxonomy per cell and pooled: labeled decoy / duplicate-positive
  match / unmatched (official classifications preserved); complete-pair
  diagnostic with sample sizes + excluded ids, explicitly never the
  primary; missing usage reported as unknown, never zero; deterministic
  ordering (sorted repos/cells, stable JSON).
- `derive_counts.py` fixed: non-scoring entries are excluded from BOTH
  vuln and decoy counts (the old helper counted them twice) and reported
  separately (with a vulnerable-non-scoring subcount).

Tests (+12, tiny injectable fake scorer with real-matcher semantics
including non-scoring withholding and nearest-line matching): complete
matrix → decision + denominators; missing trial blocks headline; extra/
duplicate cells rejected; zero predictions vs unaccounted cell; accounted
operational failure scores empty predictions with `agent_authored: false`
and keeps the denominator; setup-failure-without-inference blocks;
decision-rule truth table (≥4/6 in ≥2/3 strictly, +5 F3 boundary, +0.10
precision, ties); 6-repo positive-denominator invariant; non-scoring
labels never contribute; wrong config hash blocks; reproducible ordering;
read-only integration against the pinned checkout with the REAL scorer
(empty predictions → scored positives as FN). Suite: **478 passed, 14
skipped**.

Deviations: per-CWE/severity recall, famous/obscure splits, resource
reconciliation against gateway records, and stage-attrition tables draw
from committed cells' attempt databases and gateway JSONL — wired for the
P11 report generator, which exercises them on real matrices.

## P09 — Automated preflight gate + offline verification — COMPLETE (2026-09-22)

New `bench/realvuln/preflight.py` behind the required interface
(`python -m bench.realvuln.experiment preflight --spec SPEC --output DIR
--offline`). Machine-readable checklist with passed/failed/**not_run** per
gate — not_run is never success (CLI exit nonzero). Gates run the actual
behavior suites (no source-string checks): p01 blinded-tree tools; p02
dedupe payload bounds / report membership / state membership; p03 gateway
enforcement / real-Pi wire parity; p04 trace contracts / contracts; p05
deadlines / snapshot retention / orchestrator stage health; p06 isolation
+ corpus (real docker suite); p07 ledger / manifest+commit / adapter; p08
aggregation. Plus direct checks: benchmark source pins (HEAD + clean
tree), frozen effective-request shape (thinking enabled + reasoning_effort
low + temperature 0.6 + 32,768 tokens + no top_p + confirmed_reachable/
deterministic, fingerprint recorded), isolation image presence + pinned
build record, and freeze/load machinery end-to-end on a synthetic
experiment. The live gateway parity probe is honestly `not_run` offline.

Results (`bench/realvuln/repair-evidence/p09/preflight.json`): **20 passed,
0 failed, 1 not_run (live probe — by design until P10)**. Full offline
suite: **481 passed, 14 skipped** (`p09/pytest-final.txt`), source hashes
snapshotted (`p09/source-hashes.json`). Historical audit reproducibility:
P00 rerun of `audit_saved_run` reproduced all recorded values (40.4/20.8/
21.4 F3, 18/18 fallbacks, 340 confirmed, 0 missing traces) under the
archived scorer/adapter — the tightened adapter is new-code-only and does
not touch the historical path. The named test files from the plan all
exist and run: test_realvuln_manifest/ledger/aggregate/isolation/
preflight + test_benchmark_deadlines (plus adapter/gateway/pi-parity/
snapshot beyond the plan's list).

Deviations: none. Live probe + image-runtime isolation re-check execute at
P10 calibration, per the plan's own sequencing.

## P10 — Unscored hosted calibration — PARTIAL (live probes + smoke pair COMPLETE; VAmPI/PyGoat pairs pending) (2026-09-22)

**Live request parity probes (P03 exit gate, through the production
gateway + isolation containers)** —
`bench/realvuln/repair-evidence/p10/live-parity-records.txt` + gateway
records under `bench/realvuln-runs/gateway-probe/records/`:
- Gateway deployed as a dual-homed container (bridge for provider egress,
  private `codesec-iso-net` alias `gateway` for arms; credential injected
  operator-side only). One protocol revision, documented: the gateway
  enforces pinned dict settings by KEY SUBSET (frozen
  `thinking.type=enabled`), so Pi's undocumented `clear_thinking:false`
  member is recorded verbatim and never rewritten into apparent equality
  (test added: wrong type still rejects).
- Codesec client probe (real GLM-5.3, Read tool round-trip): payload
  correct ("42"), 4064 in / 26 out tokens.
- Pi client probe (pinned pi 0.85.1 in the isolation container; image
  rebuilt on Node 22 — pi requires node:fs globSync): read note.txt and
  replied exactly.
- **Parity verified on all 5 forwarded live requests**: model glm-5.3,
  thinking.type enabled, reasoning_effort low, temperature 0.6,
  max_tokens 32768, stream true; reasoning_tokens reported by the
  provider (0/6/7); no wrong-model request escaped validation (312 total
  gateway requests by run end, zero violations).

**Smoke H/V pair — COMPLETE and passing the P10 pass conditions**
(experiment `calib-smoke-20260922-02`, evidence under its committed/
dirs + `p10/calib-smoke-run2.log`):
- verify OK (2 cells complete and accounted); atomic commits with
  completion records.
- H stage health: dedupe **complete, 8 findings → 4 groups, zero degraded
  batches** (the bounded-payload redesign works live); deterministic
  report = intended renderer (not fallback) with report.json +
  confirmed.json + review_queue.json + checkpoint; no failures, no
  budget-limited stages.
- Tools work in production (audit finding 1 fixed): H transcripts show
  55/55 successful Reads, 2/2 nonempty Greps, Glob used, 0 tool errors;
  V executed a 3-call tool loop.
- No F3 evaluation, per plan. No isolation failures; no surviving
  processes after cells finish.
- Two earlier calibration attempts archived per plan
  (`calib-smoke-20260922-00-failed-endpoint`: profile/pi baseUrl pointed
  at 127.0.0.1 inside containers — fixed to the network alias and specs
  regenerated; `calib-smoke-20260922-01-attempt2-dedupe-conflict`: LIVE
  feedback-loop dedupe re-registered a reused group id → new
  StateConflictError — root-caused and fixed with deterministic
  collision renumbering (`g_d<member-digest>`, append-only group history
  preserved, degraded event recorded) + regression test; image rebuilt).
  Executor hardening from these attempts: post-container chown of
  attempt outputs; V model definition baseUrl now derived from the
  experiment's gateway_url.

**Artificial-deadline exercise — PASSED**
(`calib-deadline-20260922-01`, 150 s cap): recon/hunt/validate completed;
at 127.7 s the dedupe admission hit the 30 s snapshot reserve →
TimeBudgetExceededPipeline; DB run status `budget_limited`; deterministic
report CHECKPOINT written; stage ledger shows complete stages + the
budget-limited transition; zero surviving processes.

**Intentional network-error exercise — H arm PASSED**
(`calib-neterror-20260922-01`, dead gateway alias): bounded transient
retries, clean failed_no_output ledger entry with made_inference recorded,
run exited 1 in 238 s (no hang). The V cell in that experiment
accidentally used the still-live gateway alias (fixed since by deriving
V's baseUrl from gateway_url) and completed a real 13.77 s audit; the V
missing-output path shares the executor code path H exercised.

`protocol-v2.json` WRITTEN (all frozen settings: endpoint/model/reasoning
zai_thinking low/sampling 0.6 no top_p/32,768 tokens/262,144 ceiling/
concurrency/ceilings/retry+failure rules/decision rule/image id/isolation
evidence hash; effective-request fingerprint `cf9d42d2…59adf`).

**Exact remaining work (blocked only by session wall budget, not by any
defect):** VAmPI and PyGoat calibration pairs at full budgets
(`protocol-v2.json` + a two-repo calibration spec → freeze/run/verify),
then P11 `freeze` of
`glm53-repaired-regression-v2-20260922-01` and the 36-cell matrix. All
commands are the implemented CLI contract; the gateway container
(`codesec-gateway`) is running and dual-homed.

## Session summary / handoff (2026-09-22)

Final offline suite after all calibration fixes (dedupe collision
renumbering, gateway pinned-key-subset enforcement, executor chown +
V-baseUrl derivation): **483 passed, 14 skipped** (skips: 13 × absent
claude CLI, 1 × live-bench marker).

**Packages completed:** P00, P01, P02, P03 (offline gates + live probes),
P04, P05, P06, P07, P08, P09, P10-part (live parity + smoke pair +
artificial deadline + network-error exercises; protocol-v2.json written).

**Matrices that actually ran (all unscored calibration, hosted GLM-5.3
through the production gateway + isolation containers):**
- calib-smoke-20260922-02: 1 repo × 1 trial × 2 arms — COMPLETE, both
  cells committed, all P10 smoke pass conditions met.
- calib-deadline-20260922-01: 150 s artificial deadline — budget_limited
  finalization verified.
- calib-neterror-20260922-01: dead-gateway H arm — bounded failure
  verified.
- Two failed calibration attempts archived (endpoint misconfig; live
  dedupe conflict — root-caused, fixed, tested).

**Primary success criterion:** NOT YET EVALUATED — no scored matrix has
run (P11 is gated on completing P10's VAmPI/PyGoat calibration pairs).

**Blocked / remaining:**
1. P10 remainder: VAmPI + PyGoat H/V pairs at full budgets (hours of wall
   time; no known defect — the blocker is session wall budget).
2. P11: freeze + run + verify + aggregate of
   `glm53-repaired-regression-v2-20260922-01` (CLI contract implemented
   and exercised on calibration; `run` resumes idempotently).
3. P11 report document generation.
4. P12 (confirmatory cohort) — only after P11, per plan.
5. P13 (local Unsloth backend) — conditional, separate experiment.

**Resume instructions:** the gateway container `codesec-gateway` is
running (dual-homed: bridge + codesec-iso-net alias `gateway`; credential
from operator env). To continue:
  .venv/bin/python -m bench.realvuln.experiment freeze --spec <calib spec> --output <exp>
  .venv/bin/python -m bench.realvuln.experiment run --experiment <exp>
  .venv/bin/python -m bench.realvuln.experiment verify --experiment <exp>
  .venv/bin/python -m bench.realvuln.aggregate --experiment <exp> --json-out <exp>/reports/aggregate.json

**Evidence index:** `bench/realvuln/repair-evidence/p00…p10/` (baseline,
reproductions, descriptor checks, archived Z.AI docs, live parity,
calibration runs); experiments under `bench/realvuln-runs/experiments/`;
image build record `bench/realvuln-runs/image-build.json`
(`sha256:ee12a801…`, pi 0.85.1, Node 22); gateway records under
`bench/realvuln-runs/gateway-probe/records/`.
