#!/usr/bin/env python3
"""Append-only, locked, experiment-scoped attempt ledger (P07).

Replaces the old shared ``failed-trials.txt`` (copied and truncated across
waves, unscoped by tag/model/experiment). Every event carries the
experiment id, opaque ids, timestamps, the configuration hash, status,
reason code, exit status, artifact hashes and the attempt-selection reason.
The ledger is never truncated; each experiment gets its own file under
``<exp>/operator/attempts.jsonl``.

Locking: an exclusive ``fcntl`` lock on the sidecar ``.lock`` file guards
appends so two controllers cannot interleave (double-commit is additionally
prevented by completion markers, which are created atomically).
"""

from __future__ import annotations

import fcntl
import json
import os
import time
import uuid
from pathlib import Path

TERMINAL_STATUSES = frozenset({
    "completed",          # attempt produced committed outputs
    "failed_output",      # terminal run failure with output produced anyway
    "failed_no_output",   # terminal run failure without output
    "setup_failed",       # pre-inference setup failure (retry-eligible once)
    "invalidated",        # protocol breach / config mismatch
})

#: First execution after the first inference request is the operational
#: primary; later diagnostics get new attempts but cannot replace it.
PRIMARY_STATUSES = frozenset({"completed", "failed_output"})


class LedgerConflictError(RuntimeError):
    """Another controller already holds the ledger or the state conflicts."""


class AttemptLedger:
    def __init__(self, path: Path, *, experiment_id: str, config_hash: str):
        self.path = Path(path)
        self.experiment_id = experiment_id
        self.config_hash = config_hash
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock_path = self.path.with_suffix(".jsonl.lock")
        self._lock_path.touch(exist_ok=True)

    # ---- append ----------------------------------------------------------

    def append(self, event: dict) -> dict:
        record = {
            "ledger_id": uuid.uuid4().hex,
            "experiment_id": self.experiment_id,
            "config_hash": self.config_hash,
            "ts": time.time(),
            **event,
        }
        with self._lock_path.open("r+") as lock:
            fcntl.flock(lock, fcntl.LOCK_EX)
            try:
                for existing in self._iter_records():
                    self._check_conflicts(existing, record)
                with self.path.open("a") as fh:
                    fh.write(json.dumps(record, ensure_ascii=False) + "\n")
                    fh.flush()
                    os.fsync(fh.fileno())
            finally:
                fcntl.flock(lock, fcntl.LOCK_UN)
        return record

    def _check_conflicts(self, existing: dict, new: dict) -> None:
        if (
            existing.get("type") == "attempt_end"
            and existing.get("cell_id") == new.get("cell_id")
            and existing.get("attempt_id") == new.get("attempt_id")
            and new.get("type") == "attempt_end"
        ):
            raise LedgerConflictError(
                f"attempt {new.get('attempt_id')} already has a terminal "
                "record — never rewrite ledger history"
            )
        if (
            existing.get("config_hash")
            and new.get("config_hash")
            and existing["config_hash"] != new["config_hash"]
            and existing.get("experiment_id") == new.get("experiment_id")
        ):
            raise LedgerConflictError(
                "ledger events for one experiment must share one "
                f"configuration hash ({existing['config_hash']} vs "
                f"{new['config_hash']})"
            )

    # ---- read ------------------------------------------------------------

    def _iter_records(self):
        if not self.path.exists():
            return
        with self.path.open() as fh:
            for line in fh:
                line = line.strip()
                if line:
                    yield json.loads(line)

    def records(self, cell_id: str | None = None) -> list[dict]:
        return [
            r for r in self._iter_records()
            if cell_id is None or r.get("cell_id") == cell_id
        ]

    def attempts(self, cell_id: str) -> list[dict]:
        started = {
            r["attempt_id"]: r
            for r in self.records(cell_id)
            if r.get("type") == "attempt_start"
        }
        out = []
        for r in self.records(cell_id):
            if r.get("type") == "attempt_end":
                attempt = dict(started.get(r["attempt_id"], {}))
                attempt.update(r)
                out.append(attempt)
        return out

    def terminal_state(self, cell_id: str) -> dict | None:
        """Terminal state of the cell: the first inference-bearing attempt's
        end record wins (operational primary), else the last terminal."""
        ends = [r for r in self.records(cell_id)
                if r.get("type") == "attempt_end"]
        if not ends:
            return None
        inference_bearing = [
            e for e in ends
            if e.get("made_inference_requests") and e.get("status") in PRIMARY_STATUSES
        ]
        if inference_bearing:
            return inference_bearing[0]
        return ends[-1]

    def cell_accounted(self, cell_id: str) -> bool:
        state = self.terminal_state(cell_id)
        return state is not None and state.get("status") in TERMINAL_STATUSES
