"""Snapshot retention for externally-written findings files (P05/P07).

The V arm (vanilla Pi) writes its findings file from outside our control. A
truncated overwrite must never destroy the previous valid snapshot, and a
file must never be accepted while it is still being written.

Contract (used by the V-arm supervisor in the experiment runner):

- ``retain_snapshot(path)`` atomically copies the CURRENT file content only
  when it parses as complete JSON (and, when given, validates against the
  supplied schema). The copy lands under ``<path>.snapshots/`` with a
  monotonic timestamp, sha256, and capture metadata. Failed reads leave any
  previous snapshot untouched.
- ``latest_valid_snapshot(path)`` returns the newest *fully written and
  valid* snapshot at or before ``deadline_ts`` — never an in-flight write,
  never a post-deadline capture.
"""

from __future__ import annotations

import hashlib
import json
import shutil
import time
from pathlib import Path


def _snapshot_dir(path: Path) -> Path:
    return path.parent / f"{path.name}.snapshots"


def retain_snapshot(
    path: Path,
    *,
    schema_validator=None,
    tags: dict | None = None,
) -> Path | None:
    """Capture the current file if it is complete and valid.

    Returns the snapshot path, or None when the file was missing, partial,
    or invalid (previous snapshots are left intact)."""
    try:
        raw = path.read_bytes()
    except FileNotFoundError:
        return None
    try:
        payload = json.loads(raw)
    except (json.JSONDecodeError, UnicodeDecodeError):
        return None  # partial/in-flight write — keep the previous snapshot
    if schema_validator is not None:
        errors = schema_validator(payload)
        if errors:
            return None
    digest = hashlib.sha256(raw).hexdigest()
    snap_dir = _snapshot_dir(path)
    snap_dir.mkdir(parents=True, exist_ok=True)
    captured_at = time.time()
    snapshot = snap_dir / f"{int(captured_at * 1000):013d}-{digest[:12]}.json"
    shutil.copyfile(path, snapshot)
    meta = snap_dir / f"{snapshot.name}.meta.json"
    meta.write_text(json.dumps({
        "captured_at": captured_at,
        "source": str(path),
        "sha256": digest,
        "bytes": len(raw),
        "tags": tags or {},
    }, indent=1, sort_keys=True) + "\n")
    return snapshot


def latest_valid_snapshot(
    path: Path,
    *,
    deadline_ts: float | None = None,
) -> dict | None:
    """Newest retained snapshot captured at or before ``deadline_ts``
    (wall clock). Returns {'path', 'captured_at', 'sha256'} or None."""
    snap_dir = _snapshot_dir(path)
    if not snap_dir.exists():
        return None
    best: dict | None = None
    for meta_path in snap_dir.glob("*.meta.json"):
        try:
            meta = json.loads(meta_path.read_text())
        except (json.JSONDecodeError, OSError):
            continue
        captured_at = float(meta.get("captured_at", 0))
        if deadline_ts is not None and captured_at > deadline_ts:
            continue  # post-deadline captures are never used
        if best is None or captured_at > best["captured_at"]:
            best = {
                "path": str(snap_dir / meta_path.name[: -len(".meta.json")]),
                "captured_at": captured_at,
                "sha256": meta.get("sha256"),
            }
    return best
